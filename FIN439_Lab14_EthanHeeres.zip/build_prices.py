"""Build prices.csv from REAL monthly adjusted-close prices for six ETFs.

Run one of these from a terminal in the folder containing this file:
    python build_prices.py                  # try Yahoo Finance chart data
    python build_prices.py --csv-dir raw    # combine six downloaded CSVs in raw/

Expected raw files: VOO.csv, QQQ.csv, SOXX.csv, SCHD.csv, BIL.csv, BND.csv.
Each file must have a Date column and an Adj Close / AdjClose column.
No missing data are filled, and no prices are invented.
"""

import argparse
import csv
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

TICKERS = ("VOO", "QQQ", "SOXX", "SCHD", "BIL", "BND")
START_MONTH = (2021, 10)  # first completed month in the five-year sample
END_MONTH = (2026, 9)     # last completed month (Oct 2026 is unfinished)


def month_keys():
    year, month = START_MONTH
    end_year, end_month = END_MONTH
    months = []
    while (year, month) <= (end_year, end_month):
        months.append(f"{year:04d}-{month:02d}")
        month += 1
        if month == 13:
            year += 1
            month = 1
    return months


def verify_price(ticker, month, raw_price):
    try:
        price = float(raw_price)
    except (ValueError, TypeError):
        raise ValueError(f"{ticker} {month}: missing/non-numeric adjusted close.") from None
    if not math.isfinite(price) or price <= 0:
        raise ValueError(f"{ticker} {month}: adjusted close must be positive and finite.")
    return price


def yahoo_adjusted_closes(ticker):
    """Request actual monthly dividend/split-adjusted closes from Yahoo chart JSON."""
    start = int(datetime(START_MONTH[0], START_MONTH[1], 1, tzinfo=timezone.utc).timestamp())
    # End is exclusive, so use the first day after END_MONTH.
    next_year = END_MONTH[0] + (END_MONTH[1] == 12)
    next_month = END_MONTH[1] % 12 + 1
    end = int(datetime(next_year, next_month, 1, tzinfo=timezone.utc).timestamp())
    qs = urlencode({
        "period1": start, "period2": end, "interval": "1mo",
        "events": "div,splits", "includeAdjustedClose": "true",
    })
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?{qs}"
    request = Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urlopen(request, timeout=20) as response:
            data = json.load(response)
    except (HTTPError, URLError, TimeoutError) as error:
        raise RuntimeError(
            f"Yahoo download failed for {ticker}: {error}. "
            "If Yahoo blocks automated downloads, supply genuine CSVs with --csv-dir."
        ) from error
    chart = data.get("chart", {})
    if chart.get("error"):
        raise RuntimeError(f"Yahoo data error for {ticker}: {chart['error']}")
    items = chart.get("result") or []
    if not items:
        raise RuntimeError(f"Yahoo returned no price history for {ticker}.")
    item = items[0]
    timestamps = item.get("timestamp", [])
    prices = item.get("indicators", {}).get("adjclose", [{}])[0].get("adjclose", [])
    if not timestamps or len(timestamps) != len(prices):
        raise RuntimeError(f"Yahoo has missing adjusted-close data for {ticker}.")
    data_by_month = {}
    for timestamp, raw_price in zip(timestamps, prices):
        date = datetime.fromtimestamp(timestamp, tz=timezone.utc).date()
        key = date.strftime("%Y-%m")
        if raw_price is not None:
            data_by_month[key] = verify_price(ticker, key, raw_price)
    return data_by_month


def local_adjusted_closes(ticker, directory):
    """Read a genuine Yahoo-style monthly or daily CSV, using last date in each month."""
    path = directory / f"{ticker}.csv"
    if not path.is_file():
        raise FileNotFoundError(f"Missing source file: {path}")
    by_month = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "Date" not in reader.fieldnames:
            raise ValueError(f"{path.name}: missing Date column.")
        adjusted_column = next(
            (name for name in ("Adj Close", "AdjClose", "Adjusted Close") if name in reader.fieldnames),
            None,
        )
        if adjusted_column is None:
            raise ValueError(
                f"{path.name}: no adjusted close column. Unadjusted Close cannot replace it."
            )
        for row in reader:
            try:
                date = datetime.strptime(row["Date"].strip()[:10], "%Y-%m-%d").date()
            except (ValueError, AttributeError):
                continue  # skip provider's non-data/dividend event rows
            key = date.strftime("%Y-%m")
            raw = (row.get(adjusted_column) or "").strip()
            if not raw or raw.lower() in ("null", "nan"):
                continue
            price = verify_price(ticker, key, raw)
            if key not in by_month or date >= by_month[key][0]:
                by_month[key] = (date, price)
    return {month: record[1] for month, record in by_month.items()}


def build(output=Path("prices.csv"), csv_dir=None):
    months = month_keys()
    if len(months) != 60:
        raise AssertionError("Expected 60 complete months.")
    histories = {}
    for ticker in TICKERS:
        source = local_adjusted_closes(ticker, csv_dir) if csv_dir else yahoo_adjusted_closes(ticker)
        missing = [month for month in months if month not in source]
        if missing:
            raise ValueError(
                f"{ticker}: {len(missing)} missing month(s), including {', '.join(missing[:6])}. "
                "No file was written because the sample must be complete."
            )
        histories[ticker] = source
        print(f"Validated {ticker}: {len(months)} completed months.")

    # Date is normalized to month-end for clarity: a monthly data point is the
    # adjusted close for that full completed month, not necessarily the first day.
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(("Date", *TICKERS))
        for month in months:
            year, mm = map(int, month.split("-"))
            ny, nm = (year + 1, 1) if mm == 12 else (year, mm + 1)
            from datetime import timedelta
            month_end = (datetime(ny, nm, 1).date() - timedelta(days=1)).isoformat()
            writer.writerow([month_end] + [f"{histories[t][month]:.6f}" for t in TICKERS])
    print(f"Saved {output}: 60 months, six ETFs, oldest first.")
    print(f"Source: {'CSV files in ' + str(csv_dir) if csv_dir else 'Yahoo Finance chart adjusted close'}")
    print(f"Retrieval/consolidation date: {datetime.now(timezone.utc).date().isoformat()} (UTC)")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csv-dir", type=Path, help="Folder containing 6 downloaded Yahoo-style CSVs")
    parser.add_argument("--output", type=Path, default=Path("prices.csv"))
    args = parser.parse_args()
    try:
        build(args.output, args.csv_dir)
    except (ValueError, RuntimeError, FileNotFoundError) as error:
        raise SystemExit(f"Price data error: {error}")


if __name__ == "__main__":
    main()
