# FIN 439 — Lab 14

Your files are directly inside this folder. Nothing here was uploaded to GitHub.

## Run in VS Code (Windows)
Open this folder in VS Code (File > Open Folder). Open Terminal > New Terminal and run:

```powershell
py portfolio.py
py mandate.py
```

## Price history for Thursday
The six funds are VOO, QQQ, SOXX, SCHD, BIL, and BND. Try:

```powershell
py build_prices.py
```

The historical prices have **not** been included or fabricated. The downloader attempts to obtain real monthly adjusted closing prices, and if it cannot, it should report an error. Review your Lab 14 write-up and complete your personal and partner activities before submission.
