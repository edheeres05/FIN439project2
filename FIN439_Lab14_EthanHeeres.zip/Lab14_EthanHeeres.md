# Lab 14 — Portfolio Baselines

Ethan Heeres | FIN 439 | October 20, 2026

## D — Define

**Question:** What does each simple portfolio earn and risk, and does any of them meet the Meridian mandate?

The benchmark meets the 6.5% expected return target but has 0% in reserve-eligible assets. The other two portfolios satisfy the reserve minimum but do not meet the return target. **None of the three satisfies both conditions.** Meeting a return target by itself does not mean a portfolio meets the mandate.

## R — Represent

These are **course-provided practice values**, not actual forecasts of asset returns.

| Asset | Expected annual return | Annual volatility |
|---|---:|---:|
| Treasury bills | 3.5% | 0.5% |
| Treasury 10-year note | 4.3% | 7.0% |
| Investment-grade bond fund | 5.0% | 6.0% |
| Global equity index fund | 8.0% | 16.0% |

The correlations are entered in `portfolio.py` in the same asset order. The expected-return objective is **CPI + 4% = 6.5%**, using a labelled 2.5% CPI estimate. Bills and the 10-year note are reserve-eligible for Meridian; the Lab 13 checker also considers any cash allocation reserve-eligible.

## I — Implement

I used a single standard-library Python file, `portfolio.py`, which checks the inputs and calculates the covariance matrix from correlation times both assets' volatilities. Separate functions calculate benchmark weights, equal weights, inverse-volatility weights, expected return, portfolio variance, portfolio volatility, reserve weight and return-objective status.

Commands:

```bash
python portfolio.py
python mandate.py
```

`mandate.py` keeps the original A–D portfolios and adds **candidate E** as 40% investment-grade bonds and 60% global equity.

## V — Validate

| Portfolio | Weights: bills / 10-year / IG / equity | Return | Volatility | Reserve eligible | Meets 6.5% return? |
|---|---|---:|---:|---:|---|
| Benchmark | 0.0 / 0.0 / 40.0 / 60.0 | 6.80% | 10.46% | 0.0% | Yes |
| Equal weight | 25.0 / 25.0 / 25.0 / 25.0 | 5.20% | 5.21% | 50.0% | No |
| Inverse volatility | 84.3 / 6.0 / 7.0 / 2.6 | 3.77% | 1.05% | 90.3% | No |

**Changed-input checks:** I changed both IG-bond/equity correlation entries from 0.25 to 0.50; benchmark volatility rose to **11.00%**. I tested 1.3 (out-of-range) and mismatched symmetric entries; the program refused both with clear errors. I restored the original 0.25 values.

**Mandate check:** Candidate E has 0.0% reserve-eligible weight and fails Meridian's **3.0% reserve minimum**, even though it passes the other checkable holdings rules. The Lab 13 calendar-year loss promise still requires CIO clarification.

## Diversification — Learn on my own

**1. What is it?** Spreading money among different assets instead of relying entirely on one.

**2. How does it work?** When assets have correlations below +1, they do not move perfectly together. Some movements can offset one another, reducing risk compared with perfectly correlated assets. It does not eliminate the market risks that affect many assets at once.

**3. Work the benchmark's volatility by hand:**

- Return = 0.40 × 5% + 0.60 × 8% = **6.80%**.
- Bond/equity covariance = 0.25 × 0.06 × 0.16 = **0.0024**.
- Portfolio variance = (0.40² × 0.06²) + (0.60² × 0.16²) + (2 × 0.40 × 0.60 × 0.0024) = **0.010944**.
- Portfolio volatility = √0.010944 = **10.46%**. Leaving out the covariance term incorrectly gives 9.90%.

## Reflect — Draft responses to review in my own words

**Why does inverse volatility put so much into Treasury bills?** Bills have the lowest volatility, 0.5%. Taking 1 divided by volatility gives them the largest inverse-volatility value, which puts about 84% into bills. This reduces risk, but it also gives the portfolio a lower expected return.

**Which baseline would I show the CIO first?** I would start with the 60/40 benchmark because it is the client's own comparison point. It reaches the expected return objective, but the CIO needs to see that it fails the reserve rule. We cannot call it acceptable just because its return is high enough.

**Code quiz to answer independently:** In `portfolio_variance()`, why do we loop across **both** `i` and `j` instead of adding only each asset's own squared volatility? Write your own answer before asking AI to explain.

**Partner verification (complete personally):** Explain the variance loop line by line, run your partner's code, test the invalid 1.3 correlation, and record the question your partner asked. These live partner steps have **not** been represented as completed here.

## Before Thursday — My proposed Project 2 fund universe

**Six selected funds** (training/project research, not investment recommendations):

| Ticker | Fund name | Role |
|---|---|---|
| VOO | Vanguard S&P 500 ETF | Broad U.S. equity |
| QQQ | Invesco QQQ Trust | Large-cap / Nasdaq-100 growth |
| SOXX | iShares Semiconductor ETF | Concentrated semiconductor exposure |
| SCHD | Schwab U.S. Dividend Equity ETF | Dividend-oriented U.S. equity |
| BIL | SPDR Bloomberg 1–3 Month T-Bill ETF | Short-term Treasury reserve proxy |
| BND | Vanguard Total Bond Market ETF | Broad U.S. investment-grade bonds |

**Risk consideration:** VOO, QQQ, and SOXX have overlapping exposure to major technology-related companies, particularly semiconductor businesses. They are not three independent sources of diversification. BIL and BND bring different rate and credit/duration risks. BIL is an ETF reserve proxy, **not cash or a guaranteed principal balance**.

**Project scope:** Lab 13 proposed Oracle (ORCL) as a separate single-stock research focus. This new **fund-only** data universe does not itself rewrite that mandate. The previously proposed Project 2 50% VT / 40% BND / 10% BIL benchmark would need an explicit revised rule if VT is excluded; one proposed replacement for later review would be **50% VOO / 40% BND / 10% BIL**. I have not silently changed the original benchmark or risk limits.

**Market-data plan:** `build_prices.py` is set up to obtain **monthly adjusted-close (including corporate actions/dividend adjustments)** for these six funds, or combine genuine downloaded provider files. It uses **October 2021–September 2026**, 60 complete months; it deliberately does not include the unfinished October 2026 month. It saves columns `Date,VOO,QQQ,SOXX,SCHD,BIL,BND`, oldest first.

**Price source:** [Yahoo Finance Historical Data](https://finance.yahoo.com/quote/VOO/history/) (change the ticker for each fund); **price retrieval date:** pending successful download. At the time of writing, the full verified adjusted-close price data were not available in this environment. No historical prices or `prices.csv` have been fabricated. Record the actual retrieval date after running the builder successfully. Yahoo notes that direct CSV downloads may require a Gold subscription.

Fund information sources: [VOO](https://investor.vanguard.com/investment-products/etfs/profile/voo), [QQQ](https://www.invesco.com/qqq-etf/en/home.html), [SOXX](https://www.ishares.com/us/products/239705/ishares-phlx-semiconductor-etf), [SCHD](https://www.schwabassetmanagement.com/products/schd), [BIL](https://www.ssga.com/us/en/intermediary/etfs/state-street-spdr-bloomberg-1-3-month-t-bill-etf-bil), [BND](https://investor.vanguard.com/investment-products/etfs/profile/bnd).
